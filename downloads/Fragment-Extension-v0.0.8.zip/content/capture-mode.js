var de=Object.defineProperty;var ce=(r,e,t)=>e in r?de(r,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):r[e]=t;var S=(r,e,t)=>ce(r,typeof e!="symbol"?e+"":e,t);function le(r){const e=r.hostname.toLowerCase();return e.includes("pinterest.")?"pinterest":e.includes("instagram.")?"instagram":e.includes("google.")&&r.pathname.includes("search")?"google_images":"generic"}function pe(){const r=document.querySelector('meta[property="og:site_name"]');return(r==null?void 0:r.content)||document.title||void 0}function ue(r){const e=r.closest("a[href]");return e==null?void 0:e.href}function he(r){var e;return((e=r.closest("[aria-label]"))==null?void 0:e.getAttribute("aria-label"))??void 0}const R=120,ne=/\.(avif|bmp|gif|jpe?g|png|webp|svg)([?#].*)?$/i,G=new WeakMap,$=new Map,P=new Set;let X=0;function fe(r){if(r.currentSrc)return r.currentSrc;const e=ge(r.getAttribute("srcset"),location.href);return e||r.src}function ge(r,e){var t;return(t=ie(r,e).at(-1))==null?void 0:t.url}function ie(r,e){return r!=null&&r.trim()?ae(r.split(",").map(t=>{const[n,i]=t.trim().split(/\s+/);if(!n)return null;try{const a=i!=null&&i.endsWith("w")?Number.parseInt(i,10):void 0,d=i!=null&&i.endsWith("x")?Number.parseFloat(i):void 0,s={url:new URL(n,e).href,source:"srcset"};return i&&(s.descriptor=i),typeof a=="number"&&Number.isFinite(a)&&(s.width=a),typeof d=="number"&&Number.isFinite(d)&&(s.density=d),s}catch{return null}}).filter(t=>!!t)):[]}function z(r){return r.width>=R&&r.height>=R}function A(r){const e=getComputedStyle(r);return e.display!=="none"&&e.visibility!=="hidden"&&Number(e.opacity)>.05}function Y(r){return r.width<R||r.height<R||r.src.startsWith("data:image/svg")?!1:!r.src.includes("pixel")||r.width>300||r.height>300}function Z(r=document){var a,d;const e=new Map,t=le(location),n=pe();for(const s of _(r,"img")){if(!A(s))continue;const o=s.getBoundingClientRect();if(!z(o))continue;const h=fe(s),p={id:H(s,h),src:h,pageUrl:location.href,width:Math.round(o.width),height:Math.round(o.height),rect:U(o),source:t};s.currentSrc&&(p.currentSrc=s.currentSrc);const f=ue(s)??((a=s.closest("a[href]"))==null?void 0:a.href);f&&(p.sourceUrl=f),p.imageUrls=be(s,f),n&&(p.siteName=n),s.alt&&(p.alt=s.alt);const u=s.title||he(s);u&&(p.title=u),s.naturalWidth&&(p.naturalWidth=s.naturalWidth),s.naturalHeight&&(p.naturalHeight=s.naturalHeight),Y(p)&&(D(p.id,s),e.set(p.id,p))}for(const s of _(r,"video[poster]")){if(!A(s))continue;const o=s.getBoundingClientRect();if(!z(o))continue;const h=new URL(s.poster,location.href).href,p={id:H(s,h),src:h,imageUrls:[{url:h,source:"poster"}],pageUrl:location.href,width:Math.round(o.width),height:Math.round(o.height),rect:U(o),source:t};n&&(p.siteName=n),D(p.id,s),e.set(p.id,p)}for(const s of _(r,"a[href], div, section, article")){if(!A(s))continue;const o=s.getBoundingClientRect();if(!z(o))continue;const h=xe(s),p=s instanceof HTMLAnchorElement&&ne.test(s.href)?s.href:void 0,f=h??p;if(!f)continue;const u={id:H(s,f),src:f,imageUrls:[{url:f,source:h?"background":"linkedImage"}],pageUrl:location.href,width:Math.round(o.width),height:Math.round(o.height),rect:U(o),source:t};s instanceof HTMLAnchorElement&&(u.sourceUrl=s.href),n&&(u.siteName=n);const v=s.getAttribute("aria-label");v&&(u.title=v),Y(u)&&(D(u.id,s),e.set(u.id,u))}const i=(d=document.querySelector('meta[property="og:image"]'))==null?void 0:d.content;if(r===document&&i&&e.size===0){const s=new URL(i,location.href).href,o={id:s,src:s,imageUrls:[{url:s,source:"openGraph"}],pageUrl:location.href,width:640,height:360,rect:{x:24,y:24,width:180,height:120},source:t};n&&(o.siteName=n),e.set(s,o)}return[...e.values()]}function N(r){const e=$.get(r);if(e&&!e.isConnected){$.delete(r),P.delete(r);return}return e}function me(r){$.delete(r),P.delete(r)}function ve(r){const e=[];for(const t of r){if(!P.has(t.id)){e.push(t);continue}const n=N(t.id);if(!n||!A(n))continue;const i=n.getBoundingClientRect();z(i)&&e.push({...t,width:Math.round(i.width),height:Math.round(i.height),rect:U(i)})}return e}function be(r,e){return ae([r.currentSrc?{url:r.currentSrc,source:"currentSrc"}:void 0,r.src?{url:r.src,source:"src"}:void 0,...ie(r.getAttribute("srcset"),location.href),e&&ne.test(e)?{url:e,source:"sourceUrl"}:void 0])}function ae(r){const e=new Set;return r.filter(t=>!(t!=null&&t.url)||e.has(t.url)?!1:(e.add(t.url),!0))}function xe(r){const e=getComputedStyle(r).backgroundImage,t=/url\(["']?(.+?)["']?\)/.exec(e);if(t!=null&&t[1])return new URL(t[1],location.href).href}function U(r){return{x:Math.round(r.x),y:Math.round(r.y),width:Math.round(r.width),height:Math.round(r.height)}}function H(r,e){const t=G.get(r);if(t)return t;X+=1;const n=`fragment-candidate-${X}-${ke(e)}`;return G.set(r,n),n}function D(r,e){$.set(r,e),P.add(r)}function _(r,e){const t=[];return r instanceof Element&&r.matches(e)&&t.push(r),t.push(...Array.from(r.querySelectorAll(e))),t}function ke(r){let e=0;for(let t=0;t<r.length;t+=1)e=Math.imul(31,e)+r.charCodeAt(t);return Math.abs(e).toString(36)}function J(r="fragment"){const e=typeof crypto<"u"&&typeof crypto.randomUUID=="function"?crypto.randomUUID():`${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;return`${r}-${e}`}async function we({candidates:r,send:e,isCancelled:t=()=>!1,onProgress:n=()=>{}}){const i=[];for(const[a,d]of r.entries()){if(t())return W(i,!0);n({completed:a,total:r.length,candidate:d});let s;try{s=await e(d)}catch(o){s={ok:!1,error:{code:"capture_request_failed",message:o instanceof Error?o.message:"Could not save Fragment"}}}if(t())return W(i,!0);if(!s.ok)i.push({candidate:d,status:"failed",saved:0,existing:0,error:s.error});else{const o=ye(s.payload);i.push({candidate:d,status:o.saved>0?"saved":"existing",saved:o.saved,existing:o.existing})}n({completed:a+1,total:r.length,candidate:d})}return W(i,!1)}function W(r,e){let t=0,n=0;const i=[];for(const a of r)t+=a.saved,n+=a.existing,a.status==="failed"&&i.push(a.candidate);return{cancelled:e,items:r,saved:t,existing:n,failures:i.length,failedCandidates:i}}function ye(r){if(!r||typeof r!="object")return{saved:1,existing:0};const e=r,t=K(e.fragmentIds),n=K(e.duplicateOfFragmentIds);return{saved:t.length>0?t.length:typeof e.fragmentId=="string"?1:0,existing:n.length>0?n.length:typeof e.duplicateOfFragmentId=="string"?1:0}}function K(r){return Array.isArray(r)?r.filter(e=>typeof e=="string"):[]}class Ce{constructor(e=()=>{},t=()=>{}){S(this,"host",document.createElement("fragment-capture-overlay"));S(this,"shadow",this.host.attachShadow({mode:"open"}));S(this,"active",!1);S(this,"candidates",[]);S(this,"cleanupCallbacks",[]);S(this,"markerById",new Map);S(this,"openCandidateId");S(this,"hoverCandidateId");S(this,"saveBatchToken",0);S(this,"logoUrl",chrome.runtime.getURL("icons/icon-32.png"));var n;this.onRequestDisable=e,this.onRequestRefresh=t,this.host.style.position="fixed",this.host.style.inset="0",this.host.style.zIndex="2147483647",this.host.style.pointerEvents="none",this.shadow.innerHTML=`
      <style>${Ie}</style>
      <div class="layer"></div>
      <div class="multi-tray" hidden>
        <span class="tray-count">0 visible</span>
        <button type="button" class="tray-save-visible">Select visible</button>
      </div>
    `,(n=this.shadow.querySelector(".tray-save-visible"))==null||n.addEventListener("click",()=>{this.openBatchPicker()})}enable(e){document.documentElement.contains(this.host)||document.documentElement.append(this.host),this.active=!0,this.candidates=e,this.render(),this.attachGlobalEvents()}disable(){this.active=!1,this.openCandidateId=void 0,this.hoverCandidateId=void 0,this.saveBatchToken+=1,this.resetMarkerState(),this.markerById.clear(),this.cleanupCallbacks.forEach(e=>e()),this.cleanupCallbacks=[],this.host.remove()}update(e){this.active&&(this.candidates=e,this.render())}attachGlobalEvents(){if(this.cleanupCallbacks.length>0)return;const e=d=>{if(d.key==="Escape"){if(this.closePicker()){d.preventDefault(),d.stopPropagation();return}this.onRequestDisable()}},t=d=>{this.updateHoveredCandidate(d.clientX,d.clientY)},n=()=>{this.hoverCandidateId&&(this.hoverCandidateId=void 0,this.render())},i=()=>this.onRequestRefresh(),a=d=>{!this.hasOpenPicker()||this.isEventInsideOverlayPanel(d)||(this.closePicker(),this.updateHoveredCandidate(d.clientX,d.clientY))};window.addEventListener("keydown",e),window.addEventListener("pointermove",t,!0),window.addEventListener("pointerdown",a,!0),document.addEventListener("pointerleave",n),window.addEventListener("scroll",i,!0),window.addEventListener("resize",i),window.addEventListener("focus",i),document.addEventListener("visibilitychange",i),this.cleanupCallbacks.push(()=>window.removeEventListener("keydown",e)),this.cleanupCallbacks.push(()=>window.removeEventListener("pointermove",t,!0)),this.cleanupCallbacks.push(()=>window.removeEventListener("pointerdown",a,!0)),this.cleanupCallbacks.push(()=>document.removeEventListener("pointerleave",n)),this.cleanupCallbacks.push(()=>window.removeEventListener("scroll",i,!0)),this.cleanupCallbacks.push(()=>window.removeEventListener("resize",i)),this.cleanupCallbacks.push(()=>window.removeEventListener("focus",i)),this.cleanupCallbacks.push(()=>document.removeEventListener("visibilitychange",i))}render(){const e=this.shadow.querySelector(".layer");if(!e)return;this.openCandidateId&&!this.shadow.querySelector(".picker")&&(this.openCandidateId=void 0);const t=this.visibleCandidates();this.updateMultiTray(t);const n=this.activeCandidates(t),i=new Set(n.map(a=>a.id));for(const a of n){let d=this.markerById.get(a.id);d||(d=this.createMarker(),this.markerById.set(a.id,d),e.append(d)),this.updateMarker(d,a)}for(const[a,d]of this.markerById)i.has(a)||(d.remove(),this.markerById.delete(a),this.openCandidateId===a&&(this.openCandidateId=void 0))}visibleCandidates(){const e=this.viewportCandidates(80);if(this.openCandidateId&&!e.some(t=>t.id===this.openCandidateId)){const t=this.candidates.find(n=>n.id===this.openCandidateId);if(t)return[t,...e.slice(0,79)]}return e}viewportCandidates(e){const t=window.innerWidth||document.documentElement.clientWidth,n=window.innerHeight||document.documentElement.clientHeight;return this.candidates.filter(i=>{const a=i.rect;return a.x+a.width>=0&&a.y+a.height>=0&&a.x<=t&&a.y<=n}).slice(0,e)}activeCandidates(e){const t=[],n=this.hoverCandidateId?e.find(a=>a.id===this.hoverCandidateId):void 0;n&&t.push(n);const i=this.openCandidateId&&this.candidates.find(a=>a.id===this.openCandidateId);return i&&!t.some(a=>a.id===i.id)&&t.push(i),t}updateHoveredCandidate(e,t){if(!this.active||this.isPointerInsideOpenMarker(e,t))return;const n=this.candidateAtPoint(e,t);(n==null?void 0:n.id)!==this.hoverCandidateId&&(this.hoverCandidateId=n==null?void 0:n.id,this.render())}candidateAtPoint(e,t){return this.candidates.filter(n=>{const i=n.rect;return e>=i.x&&e<=i.x+i.width&&t>=i.y&&t<=i.y+i.height}).sort((n,i)=>n.rect.width*n.rect.height-i.rect.width*i.rect.height)[0]}isPointerInsideOpenMarker(e,t){if(!this.openCandidateId)return!1;const n=this.markerById.get(this.openCandidateId);if(!n)return!1;const i=n.getBoundingClientRect();return e>=i.left&&e<=i.right&&t>=i.top&&t<=i.bottom}hasOpenPicker(){return!!(this.openCandidateId||this.shadow.querySelector(".picker")||this.shadow.querySelector(".batch-picker"))}isEventInsideOverlayPanel(e){return e.composedPath().some(t=>t instanceof HTMLElement?t.classList.contains("marker")||t.classList.contains("picker")||t.classList.contains("batch-picker")||t.classList.contains("multi-tray"):!1)}closePicker(){if(!this.openCandidateId&&!this.shadow.querySelector(".picker")&&!this.shadow.querySelector(".batch-picker"))return!1;const e=this.openCandidateId;if(this.saveBatchToken+=1,this.shadow.querySelectorAll(".picker").forEach(t=>t.remove()),this.shadow.querySelectorAll(".batch-picker").forEach(t=>t.remove()),this.resetMarkerState(),this.openCandidateId=void 0,e){const t=this.markerById.get(e),n=this.candidates.find(i=>i.id===e);t&&n&&this.updateMarker(t,n)}return this.render(),!0}resetMarkerState(){this.shadow.querySelectorAll(".marker").forEach(e=>{e.classList.remove("is-open","saved","saving");const t=e.querySelector(".save-button");t&&(t.disabled=!1)})}createMarker(){const e=document.createElement("div");e.className="marker";const t=document.createElement("button");return t.type="button",t.className="save-button",e.append(t),e}updateMultiTray(e){const t=this.shadow.querySelector(".multi-tray"),n=this.shadow.querySelector(".tray-count");if(!t||!n)return;const i=e.length;t.hidden=i===0,n.textContent=`${i} visible`}updateMarker(e,t){const n=this.openCandidateId===t.id;e.dataset.candidateId=t.id,e.classList.toggle("is-open",n);const i=n?314:46;e.style.left=`${te(t.rect.x+t.rect.width-i-12,10,window.innerWidth-i-10)}px`,e.style.top=`${te(n?t.rect.y+12:t.rect.y+t.rect.height-58,10,window.innerHeight-(n?520:58))}px`;const a=e.querySelector(".save-button");a&&(a.disabled=!1,a.setAttribute("aria-label","Save Fragment"),a.title="Save Fragment",a.innerHTML=`
      <img class="fragment-logo" alt="" src="${this.logoUrl}">
      <span class="save-label">Save Fragment</span>
    `,a.onclick=d=>{d.stopPropagation(),this.openPicker(e,t)})}async openPicker(e,t){this.shadow.querySelectorAll(".picker").forEach(g=>g.remove()),this.shadow.querySelectorAll(".marker").forEach(g=>g.classList.remove("is-open")),this.openCandidateId=t.id,e.classList.add("is-open"),this.updateMarker(e,t);const n=document.createElement("form");n.className="picker",n.innerHTML=`
      <div class="picker-header">
        <strong>Save Fragment</strong>
        <span>${t.siteName??se(t.pageUrl)}</span>
      </div>
      <div class="frame-picker-shell">
        <div class="frame-picker-heading">
          <span>Frames</span>
          <div class="frame-picker-actions">
            <button class="frame-select-all" type="button">Select all</button>
            <button class="frame-select-none" type="button">Deselect</button>
          </div>
        </div>
        <div class="frame-picker" data-frame-picker></div>
      </div>
      <label>Tags <input name="tags" autocomplete="off" placeholder="texture, motion, ui"></label>
      <label>Note <textarea name="note" rows="2" placeholder="Optional note"></textarea></label>
      <div class="picker-row">
        <button class="picker-save" type="submit">Save</button>
        <button class="picker-save-visible" type="button">Save visible</button>
        <button class="picker-cancel" type="button">Never mind</button>
      </div>
      <div class="picker-row picker-row-status">
        <span class="picker-status"></span>
      </div>
      <div class="batch-results" role="status" aria-live="polite"></div>
      <p class="setup-hint"></p>
    `,n.addEventListener("click",g=>g.stopPropagation()),e.append(n);const i=n.querySelector("[data-frame-picker]"),a=n.querySelector(".picker-status"),d=n.querySelector(".setup-hint"),s=n.querySelector(".batch-results"),o=n.querySelector(".picker-save"),h=n.querySelector(".picker-save-visible"),p=n.querySelector(".picker-cancel"),f=n.querySelector(".frame-select-all"),u=n.querySelector(".frame-select-none");if(!i||!a||!d||!s||!o||!h||!p||!f||!u)return;p.addEventListener("click",()=>{this.closePicker()}),a.textContent="Loading Frames";const v=await this.loadFrames();if(this.openCandidateId!==t.id||!n.isConnected)return;if(v.ok){const g=ee(v);F(i,g),a.textContent=v.frames.length>0?"Ready":"Inbox will be created",d.textContent="",o.disabled=!1,h.disabled=!1,f.disabled=!1,u.disabled=g.length<=1}else F(i,[V()]),M(i,!0),o.disabled=!0,h.disabled=!0,f.disabled=!0,u.disabled=!0,a.textContent=v.message,d.textContent=v.setupHint;f.addEventListener("click",()=>{B(i,!0)}),u.addEventListener("click",()=>{B(i,!1)});const x=()=>{const g=new FormData(n);return{frameIds:L(i),note:String(g.get("note")??"").trim(),tags:Q(String(g.get("tags")??""))}},b=g=>{o.disabled=g||!v.ok,h.disabled=g||!v.ok,p.disabled=!1,M(i,g||!v.ok),f.disabled=g||!v.ok,u.disabled=g||!v.ok||q(i).length<=1};let y,C;n.addEventListener("submit",async g=>{if(g.preventDefault(),!v.ok)return;a.textContent="Saving",b(!0),e.classList.add("saving");const{frameIds:I,note:k,tags:l}=x();if(I.length===0){a.textContent="Select at least one Frame",e.classList.remove("saving"),b(!1);return}const c=await this.saveCandidatesToFrames(y??[t],I,k,l,a,d,s,()=>n.isConnected);if(c.ok){if(e.classList.remove("saving"),a.textContent=j(c.saved,c.existing,c.attempted,c.failures),c.failures>0){y=c.failedCandidates,o.textContent=`Retry ${c.failures} failed`,b(!1);return}y=void 0,e.classList.add("saved"),window.setTimeout(()=>{this.saveBatchToken===c.batchToken&&(n.remove(),e.classList.remove("is-open"),this.openCandidateId===t.id&&(this.openCandidateId=void 0),this.updateMarker(e,t))},900)}}),h.addEventListener("click",async()=>{if(!v.ok)return;const g=C??this.viewportCandidates(80);if(g.length===0){a.textContent="No visible images";return}const{frameIds:I,note:k,tags:l}=x();if(I.length===0){a.textContent="Select at least one Frame",e.classList.remove("saving");return}b(!0),e.classList.add("saving");const c=await this.saveCandidatesToFrames(g,I,k,l,a,d,s,()=>n.isConnected);if(c.ok){if(e.classList.remove("saving"),a.textContent=j(c.saved,c.existing,c.attempted,c.failures),c.failures>0){C=c.failedCandidates,h.textContent=`Retry ${c.failures} failed`,b(!1);return}C=void 0,e.classList.add("saved"),window.setTimeout(()=>{this.saveBatchToken===c.batchToken&&this.closePicker()},1100)}})}async openBatchPicker(){var x;this.closePicker();const e=this.viewportCandidates(80);if(e.length===0)return;const t=this.shadow.querySelector(".multi-tray");if(!t)return;(x=t.querySelector(".batch-picker"))==null||x.remove();const n=document.createElement("form");n.className="batch-picker",n.innerHTML=`
      <div class="picker-header">
        <strong>Save visible Fragments</strong>
        <span>${e.length} detected in this viewport</span>
      </div>
      <div class="frame-picker-shell">
        <div class="frame-picker-heading">
          <span>Frames</span>
          <div class="frame-picker-actions">
            <button class="frame-select-all" type="button">Select all</button>
            <button class="frame-select-none" type="button">Deselect</button>
          </div>
        </div>
        <div class="frame-picker" data-frame-picker></div>
      </div>
      <label>Tags <input name="tags" autocomplete="off" placeholder="texture, motion, ui"></label>
      <label>Note <textarea name="note" rows="2" placeholder="Optional note"></textarea></label>
      <div class="picker-row">
        <button class="picker-save" type="submit">Save ${e.length}</button>
        <button class="picker-cancel" type="button">Never mind</button>
      </div>
      <div class="picker-row picker-row-status">
        <span class="picker-status"></span>
      </div>
      <div class="batch-results" role="status" aria-live="polite"></div>
      <p class="setup-hint"></p>
    `,n.addEventListener("click",b=>b.stopPropagation()),t.append(n);const i=n.querySelector("[data-frame-picker]"),a=n.querySelector(".picker-status"),d=n.querySelector(".setup-hint"),s=n.querySelector(".batch-results"),o=n.querySelector(".picker-save"),h=n.querySelector(".picker-cancel"),p=n.querySelector(".frame-select-all"),f=n.querySelector(".frame-select-none");if(!i||!a||!d||!s||!o||!h||!p||!f)return;h.addEventListener("click",()=>this.closePicker()),a.textContent="Loading Frames";const u=await this.loadFrames();if(!n.isConnected)return;if(u.ok){const b=ee(u);F(i,b),a.textContent="Ready",d.textContent="",o.disabled=!1,p.disabled=!1,f.disabled=b.length<=1}else F(i,[V()]),M(i,!0),o.disabled=!0,p.disabled=!0,f.disabled=!0,a.textContent=u.message,d.textContent=u.setupHint;p.addEventListener("click",()=>{B(i,!0),o.textContent=T(e.length,L(i).length)}),f.addEventListener("click",()=>{B(i,!1),o.textContent=T(e.length,L(i).length)}),i.addEventListener("change",()=>{o.textContent=T(e.length,L(i).length)}),o.textContent=T(e.length,L(i).length);let v=e;n.addEventListener("submit",async b=>{if(b.preventDefault(),!u.ok)return;const y=new FormData(n),C=L(i),g=String(y.get("note")??"").trim(),I=Q(String(y.get("tags")??""));if(C.length===0){a.textContent="Select at least one Frame";return}o.disabled=!0,h.disabled=!1,p.disabled=!0,f.disabled=!0,M(i,!0);const k=await this.saveCandidatesToFrames(v,C,g,I,a,d,s,()=>n.isConnected);if(k.ok){if(a.textContent=j(k.saved,k.existing,k.attempted,k.failures),k.failures>0){v=k.failedCandidates,o.textContent=`Retry ${k.failures} failed`,o.disabled=!1,p.disabled=!1,f.disabled=q(i).length<=1,M(i,!1);return}window.setTimeout(()=>{this.saveBatchToken===k.batchToken&&n.remove()},1100)}})}async saveCandidatesToFrames(e,t,n,i,a,d,s,o){const h=this.saveBatchToken+1;this.saveBatchToken=h;const p=e.length*t.length,f=()=>this.saveBatchToken!==h||!o(),u=await we({candidates:e,isCancelled:f,send:x=>this.saveCandidate(x,t,n,i),onProgress:({completed:x,total:b})=>{if(f())return;const y=Math.min((x+1)*t.length,p);a.textContent=t.length>1?`Saving ${y}/${p} · ${t.length} Frames`:`Saving ${Math.min(x+1,b)}/${b}`}});if(u.cancelled||f())return{ok:!1,cancelled:!0};Se(s,u.items);const v=u.items.find(x=>{var b;return((b=x.error)==null?void 0:b.code)==="native_host_unavailable"});return d.textContent=v?O():"",{ok:!0,saved:u.saved,existing:u.existing,failures:u.failures,attempted:u.items.length*t.length,batchToken:h,failedCandidates:u.failedCandidates,items:u.items}}async saveCandidate(e,t,n,i){const a={type:"capture.fragment",requestId:J("capture"),frameId:t[0]||null,frameIds:t,candidate:e,requestedAt:new Date().toISOString(),extensionVersion:chrome.runtime.getManifest().version};return n&&(a.note=n),i.length>0&&(a.tags=i),await chrome.runtime.sendMessage({type:"fragment.capture.save",payload:a})}async loadFrames(){try{const e=await chrome.runtime.sendMessage({type:"fragment.frames.list",requestId:J("frames")});return e.ok&&Array.isArray(e.payload)?{ok:!0,frames:e.payload}:{ok:!1,message:e.ok?"Could not load Frames":e.error.message,setupHint:!e.ok&&e.error.code==="native_host_unavailable"?O():"Open Fragment, then try again."}}catch(e){return{ok:!1,message:"Could not reach Fragment",setupHint:e instanceof Error?e.message:O()}}}}function Q(r){const e=new Set,t=[];for(const n of r.split(",")){const i=n.trim().replace(/^#+/,""),a=i.toLowerCase();!i||e.has(a)||(e.add(a),t.push(i))}return t}function V(){return{id:"",name:"Inbox"}}function ee(r){return r.frames.length>0?r.frames.map(e=>({id:e.id,name:e.name})):[V()]}function F(r,e){r.replaceChildren(...e.map((t,n)=>{const i=document.createElement("label");i.className="frame-choice";const a=document.createElement("input");a.type="checkbox",a.name="frameIds",a.value=t.id,a.checked=n===0;const d=document.createElement("span");return d.textContent=t.name,i.append(a,d),i}))}function q(r){return Array.from(r.querySelectorAll('input[name="frameIds"]'))}function L(r){return q(r).filter(e=>e.checked).map(e=>e.value)}function B(r,e){for(const t of q(r))t.checked=e}function M(r,e){for(const t of q(r))t.disabled=e}function Se(r,e){r.replaceChildren(...e.map(t=>{var d;const n=document.createElement("div");n.className=`batch-result is-${t.status}`;const i=document.createElement("span");i.className="batch-result-title",i.textContent=t.candidate.title??t.candidate.alt??se(t.candidate.src);const a=document.createElement("span");return a.className="batch-result-state",a.textContent=t.status==="failed"?((d=t.error)==null?void 0:d.message)??"Failed":t.status==="existing"?"Already saved":"Saved",n.append(i,a),n}))}function T(r,e){return e>1?`Save ${r} to ${e} Frames`:`Save ${r}`}function O(){return`Native host is not connected. Build the host, then run scripts/install-native-host-macos.sh ${chrome.runtime.id}.`}function se(r){try{return new URL(r).host||r}catch{return r}}function te(r,e,t){return Math.min(Math.max(r,e),Math.max(e,t))}function j(r,e,t=r+e,n=0){if(n>0){const i=[];return r>0&&i.push(`Saved ${r}`),e>0&&i.push(`${e} already existed`),i.push(`${n} failed`),i.join(", ")}return e>0&&r===0?t>1?`Already saved in ${e} places`:"Already saved":e>0?`Saved ${r}, ${e} already existed`:`Saved ${r}`}const Ie=`
  :host {
    color-scheme: dark;
    --fg: #f7f7f4;
    --muted: rgba(247, 247, 244, 0.62);
    --line: rgba(255, 255, 255, 0.14);
    --glass: rgba(18, 18, 18, 0.74);
    --glass-strong: rgba(16, 16, 16, 0.94);
    --accent: #89f7ff;
    --neon: #b9ff68;
    font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Segoe UI", system-ui, sans-serif;
  }
  .layer {
    position: fixed;
    inset: 0;
    pointer-events: none;
  }
  .multi-tray {
    position: fixed;
    left: 50%;
    bottom: 18px;
    z-index: 3;
    display: flex;
    align-items: center;
    gap: 9px;
    min-height: 44px;
    padding: 6px 7px 6px 13px;
    border: 1px solid var(--line);
    border-radius: 999px;
    background:
      linear-gradient(180deg, rgba(255, 255, 255, 0.14), rgba(255, 255, 255, 0.045)),
      var(--glass);
    color: var(--fg);
    box-shadow:
      inset 0 1px 0 rgba(255, 255, 255, 0.18),
      0 18px 48px rgba(0, 0, 0, 0.32);
    pointer-events: auto;
    transform: translateX(-50%);
    -webkit-backdrop-filter: blur(24px) saturate(1.22);
    backdrop-filter: blur(24px) saturate(1.22);
  }
  .multi-tray[hidden] {
    display: none;
  }
  .tray-count {
    color: var(--muted);
    font-size: 12px;
    font-weight: 820;
    white-space: nowrap;
  }
  .tray-save-visible {
    min-height: 32px;
    padding: 0 13px;
    border: 1px solid rgba(137, 247, 255, 0.26);
    border-radius: 999px;
    background:
      linear-gradient(180deg, rgba(255, 255, 255, 0.16), rgba(255, 255, 255, 0.04)),
      rgba(0, 0, 0, 0.32);
    color: var(--fg);
    cursor: pointer;
    font-size: 12px;
    font-weight: 860;
    white-space: nowrap;
  }
  .marker {
    position: fixed;
    pointer-events: none;
  }
  .save-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    width: 44px;
    height: 44px;
    padding: 0;
    border: 1px solid rgba(255, 255, 255, 0.16);
    border-radius: 16px;
    background:
      linear-gradient(180deg, rgba(255, 255, 255, 0.18), rgba(255, 255, 255, 0.05)),
      rgba(8, 8, 8, 0.82);
    color: var(--fg);
    box-shadow:
      inset 0 1px 0 rgba(255, 255, 255, 0.2),
      0 12px 34px rgba(0, 0, 0, 0.36),
      0 0 0 1px rgba(137, 247, 255, 0.08);
    cursor: pointer;
    font-size: 12px;
    font-weight: 820;
    line-height: 1;
    pointer-events: auto;
    white-space: nowrap;
    -webkit-backdrop-filter: blur(18px) saturate(1.18);
    backdrop-filter: blur(18px) saturate(1.18);
    animation: marker-in 140ms ease-out both;
  }
  .fragment-logo {
    display: block;
    width: 27px;
    height: 27px;
    border-radius: 7px;
    object-fit: contain;
  }
  .save-label {
    display: none;
  }
  .marker.is-open .save-button,
  .save-button:hover {
    border-color: rgba(137, 247, 255, 0.42);
    color: white;
    box-shadow:
      inset 0 1px 0 rgba(255, 255, 255, 0.25),
      0 16px 42px rgba(0, 0, 0, 0.46),
      0 0 26px rgba(137, 247, 255, 0.14);
  }
  .marker.is-open .save-button {
    width: auto;
    height: 40px;
    padding: 0 13px 0 9px;
    border-radius: 999px;
  }
  .marker.is-open .save-label {
    display: inline;
  }
  .saved > .save-button {
    border-color: rgba(185, 255, 104, 0.44);
    box-shadow:
      inset 0 1px 0 rgba(255, 255, 255, 0.2),
      0 16px 42px rgba(0, 0, 0, 0.42),
      0 0 28px rgba(185, 255, 104, 0.18);
  }
  .picker,
  .batch-picker {
    display: grid;
    gap: 10px;
    width: min(292px, calc(100vw - 22px));
    max-height: min(520px, calc(100vh - 34px));
    margin-top: 8px;
    padding: 14px;
    overflow-y: auto;
    overscroll-behavior: contain;
    border: 1px solid var(--line);
    border-radius: 18px;
    background:
      linear-gradient(180deg, rgba(255, 255, 255, 0.12), rgba(255, 255, 255, 0.035)),
      var(--glass-strong);
    color: var(--fg);
    pointer-events: auto;
    box-shadow:
      inset 0 1px 0 rgba(255, 255, 255, 0.16),
      0 22px 70px rgba(0, 0, 0, 0.5);
    -webkit-backdrop-filter: blur(26px) saturate(1.18);
    backdrop-filter: blur(26px) saturate(1.18);
  }
  .batch-picker {
    position: absolute;
    left: 50%;
    bottom: calc(100% + 10px);
    transform: translateX(-50%);
  }
  .picker-header {
    display: grid;
    gap: 2px;
  }
  .picker-header strong {
    font-size: 14px;
    font-weight: 860;
  }
  .picker-header span,
  .setup-hint {
    min-width: 0;
    color: var(--muted);
    font-size: 11px;
    font-weight: 680;
    line-height: 1.35;
  }
  .frame-picker-shell {
    display: grid;
    gap: 7px;
  }
  .frame-picker-heading {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    color: rgba(247, 247, 244, 0.7);
    font-size: 11px;
    font-weight: 820;
  }
  .frame-picker-actions {
    display: flex;
    gap: 6px;
  }
  .frame-picker-actions button {
    min-height: 24px;
    padding: 0 8px;
    border: 1px solid rgba(255, 255, 255, 0.11);
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.055);
    color: var(--muted);
    cursor: pointer;
    font-size: 10px;
    font-weight: 800;
  }
  .frame-picker {
    display: grid;
    gap: 6px;
    max-height: 138px;
    overflow-y: auto;
    overscroll-behavior: contain;
    padding: 4px;
    border: 1px solid rgba(255, 255, 255, 0.11);
    border-radius: 12px;
    background: rgba(0, 0, 0, 0.18);
  }
  .frame-choice {
    display: flex;
    grid-template-columns: none;
    align-items: center;
    gap: 8px;
    min-height: 30px;
    padding: 6px 8px;
    border-radius: 9px;
    color: var(--fg);
    font-size: 12px;
    font-weight: 760;
  }
  .frame-choice:hover {
    background: rgba(255, 255, 255, 0.06);
  }
  .frame-choice input {
    flex: 0 0 auto;
    width: 15px;
    height: 15px;
    min-height: 0;
    margin: 0;
    accent-color: var(--accent);
  }
  .frame-choice span {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  label {
    display: grid;
    gap: 6px;
    color: rgba(247, 247, 244, 0.7);
    font-size: 11px;
    font-weight: 820;
  }
  select,
  input,
  textarea {
    width: 100%;
    min-height: 36px;
    border: 1px solid rgba(255, 255, 255, 0.12);
    border-radius: 10px;
    background:
      linear-gradient(180deg, rgba(255, 255, 255, 0.08), rgba(255, 255, 255, 0.025)),
      rgba(0, 0, 0, 0.32);
    color: var(--fg);
    font: inherit;
    font-size: 12px;
    padding: 8px 10px;
    outline: none;
  }
  textarea {
    min-height: 62px;
    resize: vertical;
  }
  select:disabled,
  button:disabled {
    cursor: not-allowed;
    opacity: 0.56;
  }
  .picker-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 9px;
  }
  .picker-row-status {
    min-height: 16px;
  }
  .picker-save {
    min-height: 34px;
    padding: 0 15px;
    border: 1px solid rgba(185, 255, 104, 0.34);
    border-radius: 999px;
    background: linear-gradient(180deg, var(--neon), #8eee4f);
    color: #061206;
    cursor: pointer;
    font-size: 12px;
    font-weight: 860;
  }
  .picker-save-visible,
  .picker-cancel {
    min-height: 34px;
    padding: 0 13px;
    border: 1px solid rgba(255, 255, 255, 0.13);
    border-radius: 999px;
    background:
      linear-gradient(180deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.035)),
      rgba(0, 0, 0, 0.26);
    color: var(--fg);
    cursor: pointer;
    font-size: 12px;
    font-weight: 820;
  }
  .picker-cancel {
    color: var(--muted);
  }
  .picker-status {
    min-width: 0;
    color: var(--accent);
    font-size: 11px;
    font-weight: 820;
    line-height: 1.25;
  }
  .batch-results {
    display: grid;
    gap: 5px;
    max-height: 112px;
    overflow-y: auto;
  }
  .batch-results:empty {
    display: none;
  }
  .batch-result {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    align-items: center;
    gap: 8px;
    min-height: 28px;
    padding: 5px 7px;
    border: 1px solid rgba(255, 255, 255, 0.09);
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.035);
    font-size: 10px;
  }
  .batch-result-title {
    overflow: hidden;
    color: var(--muted);
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .batch-result-state {
    color: var(--accent);
    font-weight: 820;
  }
  .batch-result.is-failed .batch-result-state {
    color: #ff9d99;
  }
  .setup-hint {
    margin: 0;
    color: rgba(255, 255, 255, 0.56);
    word-break: break-word;
  }

  /* Paper Capture system — on-page UI stays solid dark for reliable contrast. */
  :host {
    --canvas: #080a0a;
    --canvas-soft: #111413;
    --surface: rgba(26, 29, 27, 0.94);
    --surface-strong: #202421;
    --hover: rgba(44, 50, 46, 0.9);
    --line: rgba(255, 255, 255, 0.105);
    --line-strong: rgba(255, 255, 255, 0.18);
    --fg: #f4f7f2;
    --muted: #b3bab0;
    --faint: #7f887f;
    --accent: #89f7ff;
    --primary: #79e1a2;
    --on-primary: #061b11;
    --danger: #f27b72;
  }
  button:focus-visible,
  input:focus-visible,
  textarea:focus-visible,
  summary:focus-visible {
    outline: 2px solid var(--accent);
    outline-offset: 2px;
  }
  .multi-tray {
    min-height: 52px;
    gap: 8px;
    padding: 6px 6px 6px 8px;
    border: 1px solid var(--line-strong);
    border-radius: 999px;
    background: var(--surface-strong);
    box-shadow: 0 18px 48px rgba(0, 0, 0, 0.42);
    -webkit-backdrop-filter: none;
    backdrop-filter: none;
  }
  .tray-summary {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding-left: 2px;
    color: var(--muted);
    font-size: 11px;
    white-space: nowrap;
  }
  .tray-count {
    display: grid;
    min-width: 30px;
    height: 30px;
    place-items: center;
    border-radius: 999px;
    background: var(--canvas-soft);
    color: var(--fg);
    font-size: 12px;
    font-weight: 700;
  }
  .tray-save-visible {
    min-height: 38px;
    padding: 0 14px;
    border: 1px solid transparent;
    border-radius: 999px;
    background: var(--primary);
    color: var(--on-primary);
    font-size: 12px;
    font-weight: 700;
  }
  .tray-save-visible:hover { background: #8ce8ad; }
  .tray-close,
  .picker-cancel {
    display: grid;
    width: 34px;
    height: 34px;
    min-height: 0;
    flex: 0 0 auto;
    place-items: center;
    padding: 0;
    border: 1px solid var(--line);
    border-radius: 999px;
    background: var(--canvas-soft);
    color: var(--muted);
    cursor: pointer;
  }
  .tray-close:hover,
  .picker-cancel:hover { background: var(--hover); color: var(--fg); }
  .tray-close svg,
  .picker-cancel svg {
    width: 17px;
    height: 17px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.6;
    stroke-linecap: round;
  }
  .save-button {
    width: 44px;
    height: 44px;
    border: 1px solid var(--line-strong);
    border-radius: 14px;
    background: var(--surface-strong);
    box-shadow: 0 12px 34px rgba(0, 0, 0, 0.44);
    -webkit-backdrop-filter: none;
    backdrop-filter: none;
  }
  .capture-mark {
    display: grid;
    width: 24px;
    height: 24px;
    place-items: center;
    border-radius: 7px;
    background: var(--primary);
    color: var(--on-primary);
  }
  .capture-mark svg {
    width: 16px;
    height: 16px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.7;
    stroke-linejoin: round;
  }
  .marker.is-open .save-button,
  .save-button:hover {
    border-color: var(--accent);
    background: var(--surface-strong);
    box-shadow: 0 14px 38px rgba(0, 0, 0, 0.48);
  }
  .marker.is-open .save-button {
    height: 40px;
    padding: 0 12px 0 8px;
    border-radius: 999px;
  }
  .save-label { font-size: 12px; font-weight: 680; }
  .saving > .save-button { border-color: var(--accent); }
  .saved > .save-button { border-color: var(--primary); box-shadow: 0 14px 38px rgba(0, 0, 0, 0.48); }
  .picker,
  .batch-picker {
    width: min(364px, calc(100vw - 20px));
    max-height: min(610px, calc(100vh - 24px));
    gap: 16px;
    padding: 16px;
    border: 1px solid var(--line-strong);
    border-radius: 14px;
    background: var(--surface-strong);
    box-shadow: 0 24px 72px rgba(0, 0, 0, 0.56);
    -webkit-backdrop-filter: none;
    backdrop-filter: none;
  }
  .batch-picker { width: min(408px, calc(100vw - 20px)); }
  .picker-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
  }
  .picker-header > div { display: grid; min-width: 0; gap: 3px; }
  .picker-header strong { font-size: 16px; font-weight: 700; letter-spacing: -0.2px; }
  .picker-header span { overflow: hidden; color: var(--muted); font-size: 11px; line-height: 15px; text-overflow: ellipsis; white-space: nowrap; }
  .frame-picker-shell { gap: 8px; }
  .frame-picker-heading {
    color: var(--faint);
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.8px;
    text-transform: uppercase;
  }
  .frame-picker-actions { gap: 8px; }
  .frame-picker-actions button {
    min-height: 24px;
    padding: 0;
    border: 0;
    border-radius: 4px;
    background: transparent;
    color: var(--muted);
    font-size: 10px;
    text-transform: none;
    letter-spacing: 0;
  }
  .frame-picker-actions button:hover { color: var(--fg); }
  .frame-picker {
    max-height: 168px;
    gap: 4px;
    padding: 4px;
    border: 1px solid var(--line);
    border-radius: 8px;
    background: var(--canvas-soft);
  }
  .frame-choice {
    display: grid;
    grid-template-columns: 18px 24px minmax(0, 1fr);
    align-items: center;
    gap: 8px;
    min-height: 42px;
    padding: 0 9px;
    border-radius: 8px;
    color: var(--fg);
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
  }
  .frame-choice:has(input:checked) { background: var(--hover); }
  .frame-choice input {
    width: 16px;
    height: 16px;
    accent-color: var(--primary);
  }
  .frame-choice-icon {
    display: grid;
    width: 24px;
    height: 24px;
    place-items: center;
    border-radius: 6px;
    background: rgba(121, 225, 162, 0.1);
    color: var(--primary);
  }
  .frame-choice-icon svg,
  .source-note svg {
    width: 15px;
    height: 15px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.5;
    stroke-linecap: round;
    stroke-linejoin: round;
  }
  .frame-choice-name { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .picker-field { display: grid; gap: 7px; color: var(--faint); font-size: 10px; font-weight: 700; letter-spacing: 0.7px; text-transform: uppercase; }
  .picker-field input,
  .note-field textarea {
    min-height: 38px;
    padding: 0 11px;
    border: 1px solid var(--line);
    border-radius: 8px;
    background: var(--canvas-soft);
    color: var(--fg);
    font-size: 12px;
    font-weight: 500;
    letter-spacing: 0;
    text-transform: none;
  }
  .picker-field input::placeholder,
  .note-field textarea::placeholder { color: var(--faint); }
  .note-field {
    display: grid;
    gap: 8px;
    color: var(--muted);
  }
  .note-field summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    list-style: none;
  }
  .note-field summary::-webkit-details-marker { display: none; }
  .note-field summary::before { content: "+"; margin-right: 7px; color: var(--primary); }
  .note-field summary span { margin-left: auto; color: var(--faint); font-size: 10px; font-weight: 500; }
  .note-field textarea { min-height: 64px; padding: 9px 11px; resize: vertical; }
  .picker-actions {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto;
    gap: 8px;
  }
  .batch-picker .picker-actions { grid-template-columns: 1fr; }
  .picker-save,
  .picker-save-visible {
    min-height: 40px;
    padding: 0 14px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 700;
  }
  .picker-save {
    border: 1px solid transparent;
    background: var(--primary);
    color: var(--on-primary);
  }
  .picker-save:hover { background: #8ce8ad; }
  .picker-save-visible {
    border: 1px solid var(--line-strong);
    background: var(--canvas-soft);
    color: var(--fg);
  }
  .picker-save-visible:hover { background: var(--hover); }
  .picker-row-status { min-height: 0; }
  .picker-status { color: var(--accent); font-size: 11px; font-weight: 600; }
  .picker-status:empty,
  .setup-hint:empty { display: none; }
  .setup-hint { color: var(--danger); font-size: 10px; line-height: 14px; }
  .source-note {
    display: flex;
    align-items: center;
    gap: 6px;
    margin: 0;
    color: var(--faint);
    font-size: 10px;
    line-height: 14px;
  }
  .source-note svg { width: 14px; height: 14px; flex: 0 0 auto; }
  .preview-strip {
    display: grid;
    grid-template-columns: repeat(5, 1fr);
    gap: 5px;
    height: 64px;
  }
  .preview-strip img,
  .preview-strip > span {
    width: 100%;
    height: 64px;
    border: 1px solid var(--line);
    border-radius: 8px;
    object-fit: cover;
    background: var(--canvas-soft);
  }
  .preview-strip > span { display: grid; place-items: center; color: var(--muted); font-size: 11px; font-weight: 700; }
  .batch-results { max-height: 96px; gap: 4px; }
  .batch-result { min-height: 30px; border-color: var(--line); background: var(--canvas-soft); }
  .batch-result-state { color: var(--primary); }
  .batch-result.is-failed .batch-result-state { color: var(--danger); }

  /* Preserve the existing Capture geometry and behavior; update appearance only. */
  .multi-tray {
    min-height: 44px;
    gap: 9px;
    padding: 6px 7px 6px 13px;
  }
  .tray-count {
    display: inline;
    min-width: 0;
    height: auto;
    padding: 0;
    background: transparent;
    color: var(--muted);
    font-size: 12px;
  }
  .tray-save-visible {
    min-height: 32px;
    padding: 0 13px;
  }
  .picker-cancel {
    display: inline-flex;
    width: auto;
    height: auto;
    min-height: 34px;
    padding: 0 13px;
    border-radius: 8px;
  }
  .picker,
  .batch-picker {
    width: min(292px, calc(100vw - 22px));
    max-height: min(520px, calc(100vh - 34px));
    gap: 10px;
    padding: 14px;
  }
  .picker-header {
    display: grid;
    gap: 2px;
  }
  .picker-header span {
    white-space: normal;
  }
  .frame-picker {
    gap: 6px;
    max-height: 138px;
    padding: 4px;
  }
  .frame-choice {
    display: flex;
    grid-template-columns: none;
    gap: 8px;
    min-height: 30px;
    padding: 6px 8px;
  }
  label {
    color: var(--muted);
  }
  select,
  input,
  textarea {
    border-color: var(--line);
    border-radius: 8px;
    background: var(--canvas-soft);
  }
  .picker-row-status {
    min-height: 16px;
  }

  @keyframes marker-in {
    from {
      opacity: 0;
      transform: translateY(5px) scale(0.95);
    }
    to {
      opacity: 1;
      transform: translateY(0) scale(1);
    }
  }
`,Ee=140;function re(){if(window.__fragmentCaptureMode)return window.__fragmentCaptureMode;let r,e,t;const n=new Map,i=new Map,a=new Set,d=new Set,s=new Ce(()=>r.disable(),()=>u()),o=typeof IntersectionObserver=="function"?new IntersectionObserver(l=>{for(const c of l){const m=c.target.getAttribute("data-fragment-candidate-observed");m&&(c.isIntersecting?a.add(m):a.delete(m))}u()},{rootMargin:"160px"}):void 0,h=new MutationObserver(l=>{if(!(!r.enabled||document.hidden)){for(const c of l){if(c.type==="attributes"){c.target instanceof Element&&p(c.target);continue}for(const m of c.addedNodes)m instanceof Element?p(m.tagName==="SOURCE"&&m.parentElement?m.parentElement:m):m instanceof DocumentFragment&&p(m)}f()}});function p(l){l instanceof Element&&(l.matches("fragment-capture-overlay")||l.closest("fragment-capture-overlay"))||d.add(l)}function f(){window.clearTimeout(e),e=window.setTimeout(()=>{e=void 0;const l=Le([...d]);d.clear(),b(l)},Ee)}function u(){!r.enabled||document.hidden||t!==void 0||(t=window.requestAnimationFrame(()=>{t=void 0,s.update(v())}))}function v(){const l=o?[...n.values()].filter(c=>a.has(c.id)||!N(c.id)):[...n.values()];return ve(l)}function x(l=!0){const c=Z(document),m=new Set(c.map(w=>w.id));for(const w of n.keys())m.has(w)||C(w);for(const w of c)y(w);l&&u()}function b(l){for(const c of l){const m=g(c),w=Z(c),oe=new Set(w.map(E=>E.id));for(const E of m)oe.has(E)||C(E);for(const E of w)y(E)}I(),u()}function y(l){n.set(l.id,l);const c=N(l.id);if(!c){a.add(l.id);return}const m=i.get(l.id);m&&m!==c&&(o==null||o.unobserve(m),m.removeAttribute("data-fragment-candidate-observed")),m!==c&&(i.set(l.id,c),c.setAttribute("data-fragment-candidate-observed",l.id),o==null||o.observe(c)),(!o||Me(l))&&a.add(l.id)}function C(l){const c=i.get(l);c&&(o==null||o.unobserve(c),c.removeAttribute("data-fragment-candidate-observed")),i.delete(l),a.delete(l),n.delete(l),me(l)}function g(l){const c=[];for(const m of n.keys()){const w=N(m);w&&(l===w||l instanceof Node&&l.contains(w))&&c.push(m)}return c}function I(){for(const l of n.keys()){const c=i.get(l);c&&!c.isConnected&&C(l)}}function k(){if(!(!r.enabled||document.hidden)){h.observe(document.documentElement,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["src","srcset","style","poster"]});for(const l of i.values())o==null||o.observe(l)}}return r={enabled:!1,overlay:s,observer:h,refresh:()=>x(),enable:()=>{if(r.enabled){x();return}r.enabled=!0,x(!1),r.overlay.enable(v()),k()},disable:()=>{r.enabled=!1,window.clearTimeout(e),e=void 0,d.clear(),t!==void 0&&(window.cancelAnimationFrame(t),t=void 0),h.disconnect(),o==null||o.disconnect();for(const l of[...n.keys()])C(l);s.disable()}},document.addEventListener("visibilitychange",()=>{if(r.enabled){if(document.hidden){h.disconnect(),o==null||o.disconnect();return}x(),k()}}),window.__fragmentCaptureMode=r,r}function Le(r){return r.filter((e,t)=>e instanceof Node?!r.some((n,i)=>t!==i&&n instanceof Node&&n!==e&&n.contains(e)):!0)}function Me(r){return r.rect.x+r.rect.width>=-160&&r.rect.y+r.rect.height>=-160&&r.rect.x<=window.innerWidth+160&&r.rect.y<=window.innerHeight+160}chrome.runtime.onMessage.addListener(r=>{if(r.type==="fragment.capture.toggle"){const e=re();e.enabled?e.disable():e.enable()}r.type==="fragment.capture.disable"&&re().disable()});
